//
//  Items.swift
//  PersonalProject1.0
//
//  Created by Delstun McCray on 9/2/21.
//

import Foundation

struct TheTopLevelObject: Codable {
    let data: [String: Items]
    
}

struct Items: Codable {
    let name: String
    let description: String
    let plaintext: String
    let image: ItemImage
    let gold: ItemGold
    let stats: ItemStats
}

struct ItemImage: Codable {
    let full: String
    let sprite: String
    
}

struct ItemGold: Codable {
    let base: Int
    let total: Int
    let sell: Int
    
}

struct ItemStats: Codable {
    //let FlatMovementSpeedMod: Int
    
}
