//
//  ChampionDetailsViewController.swift
//  PersonalProject1.0
//
//  Created by Delstun McCray on 8/22/21.
//

import UIKit

class ChampionDetailsViewController: UIViewController {
    
    //MARK: - Landing Pad
    var champion: ChampionInfo?
    
    //MARK: - Outlets
    @IBOutlet weak var championImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var blurbLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()
        colorGradient()
        championImageView.layer.cornerRadius = championImageView.frame.height / 4.0
        championImageView.layer.borderColor = UIColor.black.cgColor
        championImageView.layer.borderWidth = 3
        
    }//end of func
    
    func updateViews() {
        guard let champions = champion else { return }
        
        let underlineAttriString = NSAttributedString(string: champions.name,
                                                      attributes: [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
        nameLabel.attributedText = underlineAttriString
        titleLabel.text = champions.title
        blurbLabel.text = champions.blurb
        
        nameLabel.textColor = .white
        titleLabel.textColor = .white
        blurbLabel.textColor = .white
        
        ChampionController.fetchImageFor(championInfo: champions) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let full):
                    self.championImageView.image = full
                case .failure(_):
                    self.championImageView.image = UIImage(systemName: "Square")
                }
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toStatsVC" {
            
           guard let destination = segue.destination as? ChampionStatsViewController else { return }
            
            let statScreen = champion
            destination.champion = statScreen
            
        }
        
    }
    
    func colorGradient() {

        let gradientLayer = CAGradientLayer()

        gradientLayer.frame = self.view.bounds

        gradientLayer.colors = [UIColor.black.cgColor, UIColor.black.cgColor, UIColor.blue.cgColor, UIColor.cyan.cgColor]


        self.view.layer.insertSublayer(gradientLayer, at: 0)
    }

}//end of class

extension UIView{
    func addGradientBackground(firstColor: UIColor, secondColor: UIColor, thirdColor: UIColor, fourthColor: UIColor, fifthColor: UIColor){
        clipsToBounds = true
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [firstColor.cgColor, secondColor.cgColor, thirdColor.cgColor, fourthColor.cgColor, fifthColor.cgColor]
        gradientLayer.frame = self.bounds
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 0)
        print(gradientLayer.frame)
        self.layer.insertSublayer(gradientLayer, at: 0)
    }
}
