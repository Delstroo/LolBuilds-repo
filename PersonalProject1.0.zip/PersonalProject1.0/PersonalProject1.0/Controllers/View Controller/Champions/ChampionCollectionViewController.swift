//
//  ChampionCollectionViewController.swift
//  PersonalProject1.0
//
//  Created by Delstun McCray on 8/22/21.
//

import UIKit

private let reuseIdentifier = "championInfoCell"

import UIKit

class CharacterCollectionViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var championSearchBar: UISearchBar!
    @IBOutlet weak var championCollectionView: UICollectionView!
    
    var champions: [ChampionInfo] = []
    
    var allChampions: [ChampionInfo] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchAllChampions()
        updateViews()
        colorGradient()
        championCollectionView.delegate = self
        championCollectionView.dataSource = self
        championSearchBar.delegate = self
        self.hideKeyboardWhenTappedAround()
    }
    
    func updateViews() {
        championCollectionView.reloadData()
        
    }
    
    //MARK: - Helper Functions
    
    func fetchAllChampions() {
        
        ChampionController.fetchChampions() { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let champions):
                    self.champions = champions
                    self.allChampions = champions
                    self.updateViews()
                case .failure(let error):
                    print("Error in \(#function) : \(error.localizedDescription) \n---\n \(error)")
                }
            }
        }
        
    }//end of func
    
    // MARK: UICollectionViewDataSource

    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return champions.count
        
    }//
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "championInfoCell", for: indexPath) as? ChampionCollectionViewCell else {return UICollectionViewCell() }
        
        let character = champions[indexPath.row]
        
        cell.champions = character
        cell.layer.cornerRadius = 1/2
        cell.layer.borderWidth = 0
        cell.layer.shadowColor = UIColor.black.cgColor
        cell.layer.shadowOffset = CGSize(width: 0, height: 2.0)
        cell.layer.shadowRadius = 50.0
        cell.layer.shadowOpacity = 1
        cell.layer.masksToBounds = false
        
        return cell
    }//end of func
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toDetailVC" {
            
            guard let cell = sender as? ChampionCollectionViewCell,
                  let indexPath = championCollectionView.indexPath(for: cell),
                  let destination = segue.destination as?
                    ChampionDetailsViewController else { return }
            let selectedChampion = champions[indexPath.row]
            destination.champion = selectedChampion
            
            
            
        }
        
    }//end of func
    
    func colorGradient() {

        
        let gradientCollection = CAGradientLayer()
        
        gradientCollection.frame = self.championCollectionView.bounds
        
        gradientCollection.colors = [UIColor.black.cgColor, UIColor.black.cgColor, UIColor.blue.cgColor, UIColor.cyan.cgColor]
        
        self.championCollectionView.backgroundView = UIView.init(frame: self.view.bounds)
        
        self.championCollectionView.backgroundView?.layer.insertSublayer(gradientCollection, at: 0)
        
    }
        
}//end of class


extension CharacterCollectionViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        let oneCellWidth = view.frame.width * 0.45
        
        let cellsTotalWidth = oneCellWidth * 2
        
        let leftOverWidth = view.frame.width - cellsTotalWidth
        
        let inset = leftOverWidth / 3
        
        return UIEdgeInsets(top: inset, left: inset, bottom: 0, right: inset)
    }
    
}//end of extension

extension CharacterCollectionViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        self.champions = allChampions
        
        guard let searchTerm = searchBar.text, !searchTerm.isEmpty else {
            self.championCollectionView.reloadData()
            return }
        
        let filteredChampions = champions.filter {
            
            $0.name.localizedCaseInsensitiveContains(searchTerm)
        }
        
        self.champions = filteredChampions
        self.championCollectionView.reloadData()
        
    }
  
}//End of extension

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}//End of extension
