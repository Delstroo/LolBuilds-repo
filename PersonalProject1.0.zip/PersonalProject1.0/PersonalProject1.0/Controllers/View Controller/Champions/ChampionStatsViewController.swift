//
//  ChampionStatsViewController.swift
//  PersonalProject1.0
//
//  Created by Delstun McCray on 9/1/21.
//

import UIKit

class ChampionStatsViewController: UIViewController {
    
    //MARK: - Landing Pad
    var stats: ChampionStats?
    
    var champion: ChampionInfo? {
        didSet {
            self.stats = self.champion?.stats
            
        }
    }
    
    //MARK: - Outlets
    
    @IBOutlet weak var hpLabel: UILabel!
    @IBOutlet weak var hpPerLevelLabel: UILabel!
    @IBOutlet weak var hpRegenLabel: UILabel!
    @IBOutlet weak var hpRegenPerLevelLabel: UILabel!
    @IBOutlet weak var magicPenLabel: UILabel!
    @IBOutlet weak var mpPerLevelLabel: UILabel!
    @IBOutlet weak var movementSpeedLabel: UILabel!
    @IBOutlet weak var armourLabel: UILabel!
    @IBOutlet weak var armourPerLevelLabel: UILabel!
    @IBOutlet weak var spellBlockLabel: UILabel!
    @IBOutlet weak var spellBlockPerLevelLabel: UILabel!
    @IBOutlet weak var attackRangePerLevel: UILabel!
    @IBOutlet weak var mpRegenLabel: UILabel!
    @IBOutlet weak var mpRegenPerLevelLabel: UILabel!
    @IBOutlet weak var critChanceLabel: UILabel!
    @IBOutlet weak var critChancePerLevelLabel: UILabel!
    @IBOutlet weak var attackDamageLabel: UILabel!
    @IBOutlet weak var attackDamagePerLevelLabel: UILabel!
    @IBOutlet weak var attackSpeedLabel: UILabel!
    @IBOutlet weak var attackSpeedPerLevelLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        guard stats != nil else { return }
        updateViews()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
    }
    
    func updateViews() {
        guard let stats = stats else { return }
        
        hpLabel.text = "\(stats.hp)"
        hpPerLevelLabel.text = "\(stats.hpperlevel)"
        magicPenLabel.text = "\(stats.mp)"
        mpPerLevelLabel.text = "\(stats.mpperlevel)"
        movementSpeedLabel.text = "\(stats.movespeed)"
        armourLabel.text = "\(stats.armor)"
        armourPerLevelLabel.text = "\(stats.armorperlevel)"
        spellBlockLabel.text = "\(stats.spellblock)"
        spellBlockPerLevelLabel.text = "\(stats.spellblockperlevel)"
        attackRangePerLevel.text = "\(stats.attackrange)"
        hpRegenLabel.text = "\(stats.hpregen)"
        hpRegenPerLevelLabel.text = "\(stats.hpregenperlevel)"
        critChanceLabel.text = "\(stats.crit)"
        critChancePerLevelLabel.text = "\(stats.critperlevel)"
        attackDamageLabel.text = "\(stats.attackdamage)"
        attackDamagePerLevelLabel.text = "\(stats.attackdamageperlevel)"
        attackSpeedLabel.text = "\(stats.attackspeed)"
        attackSpeedPerLevelLabel.text = "\(stats.attackspeedperlevel)"
        mpRegenLabel.text = "\(stats.mpregen)"
        mpRegenPerLevelLabel.text = "\(stats.mpregenperlevel)"
        
        
    }
    
}
