//
//  ViewController.swift
//  PersonalProject1.0
//
//  Created by Delstun McCray on 8/22/21.
//

import UIKit

class FirstSelectorViewController: UIViewController {

    @IBOutlet weak var championButton: UIButton!
    @IBOutlet weak var buildsButton: UIButton!
    @IBOutlet weak var itemButtons: UIButton!
    
    
    //MARK: - LifeCycles
    override func viewDidLoad() {
        super.viewDidLoad()
       // fetchData()
        updateViews()
        
        championButton.layer.cornerRadius = championButton.frame.height / 8
        championButton.layer.masksToBounds = true
        buildsButton.layer.cornerRadius = buildsButton.frame.height / 8
        buildsButton.layer.masksToBounds = true
        itemButtons.layer.cornerRadius = itemButtons.frame.height / 8
        itemButtons.layer.masksToBounds = true


    }//End of func
    
    
    func updateViews() {
        
            let gradientLayer = CAGradientLayer()

            gradientLayer.frame = self.view.bounds

            gradientLayer.colors = [UIColor.black.cgColor, UIColor.black.cgColor, UIColor.blue.cgColor, UIColor.cyan.cgColor]


            self.view.layer.insertSublayer(gradientLayer, at: 0)
        }//End of func
    
    @IBAction func championButtonTapped(_ sender: Any) {
    }
    @IBAction func itemsButtonTapped(_ sender: Any) {
    }
    @IBAction func buildsButtonTapped(_ sender: Any) {
    }
    
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    

}
